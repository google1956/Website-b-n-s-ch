﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WedStore.Const
{
    public class ConstValue
    {
        public static string ConnectString = "Data Source=DESKTOP-QSUKVDA;Database=QLStore;Trusted_Connection=True;";

    }
}
