- Mở Microsoft SQL Server: chạy file QLSTORE.sql

- mở project bằng Visual Studio và chạy project

*tài khoản đăng nhập:
superadmin - 123456
admin - 123456
customer1 - 123456